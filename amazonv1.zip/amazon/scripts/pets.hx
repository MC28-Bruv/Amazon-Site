function onCreatePost() {
	switch (pet.curPet) {
		case 'motherof40pets':
            pet.y += 150;
		case 'pinkparasite':
            pet.y -= 1100;
			pet.x -= 300;
			pet.scale.y = pet.scale.x = 3;
			if (songName == 'Ejected') {
				pet.y += 100;
				pet.x -= 1000;
			}
		case 'tinytomonguspixel':
            pet.y -= 150;
			pet.scale.y = pet.scale.x = 6;
			pet.antialiasing = false;
		case 'charlespet':
			pet.scale.y = pet.scale.x = 0.5;
	}
}

function onUpdate() {
	switch (pet.curPet) {
		case 'pinkparasite':
			if (songName == 'Ejected') {
				pet.angle = 0;
			} else if (songName == 'Identity Crisis') {
				pet.angle = 0;
			}
	}
}