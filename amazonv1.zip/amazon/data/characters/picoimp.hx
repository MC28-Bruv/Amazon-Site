function onCreatePost() {
	if (songName == 'Turbulence') {
		game.boyfriend.y += 300;
	}
}