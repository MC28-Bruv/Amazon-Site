import openfl.filters.ShaderFilter;
import flixel.addons.display.FlxRuntimeShader;
import flixel.FlxG;

var bodyTypes = ['normal', 'short', 'tall'];
public var colors = [0xFFFFFF, 0xFF0000, 0xFFFF00, 0x00FF00, 0x00FFFF, 0xFF00FF, 0x0000FF, 0xFF7B00];
public var visorcolors = [0x60D0FF, 0x60D0FF, 0x60D0FF, 0x60D08A, 0xAA23B9, 0x522019, 0x000B19];
var cosmetics = ['invis', 'invis', 'invis', 'dumsticker', 'eye', 'eyebrows', 'eyebrowsmad', 'glasses', 'reindeernose', 'bigasshat'];
var cosmeticnum = FlxG.random.float(0, cosmetics.length);
var chosenBodyType;
var crewColor = FlxG.random.float(-1, colors.length);
var davisorcolor = FlxG.random.float(0, visorcolors.length);
var bfRGB:FlxRuntimeShader = null;
var iconRGB:FlxRuntimeShader = null;
var ghostRGB:FlxRuntimeShader = null;
var tooguscosmetic:FlxSpriteElement;
var tooguscosmeticextra:FlxSpriteElement;
public var cosmetic:FlxSprite;
public var cosmeticExtra:FlxSprite;
var doCosmeticExtra:Bool = false;

function onCreatePost() {
    chosenBodyType = FlxG.random.float(0, 2);

    changeCharacter(bodyTypes[chosenBodyType] + 'Body', 0);
    playHUD.iconP1.changeIcon(bodyTypes[chosenBodyType] + 'Type');

    if (!(crewColor == -1)) {
        playHUD.healthBar.setColors(dad.healthColour, colors[crewColor]);
        boyfriend.healthColour = colors[crewColor];

        var frag:String = Paths.getTextFromFile('shaders/rgb.frag');

        bfRGB = new FlxRuntimeShader(frag);
        bfRGB.setFloat('visor', 1);
        bfRGB.setFloat('opacity', boyfriend.alpha);
        boyfriend.shader = bfRGB;

        iconRGB = new FlxRuntimeShader(frag);
        iconRGB.setFloatArray('green', [96 / 255, 208 / 255, 1]);
        iconRGB.setFloat('visor', 1);
        iconRGB.setFloat('opacity', camHUD.alpha);
        playHUD.iconP1.shader = iconRGB;

        ghostRGB = new FlxRuntimeShader(frag);
        ghostRGB.setFloat('visor', 1);
        ghostRGB.setFloat('opacity', boyfriend.doubleGhosts[0].alpha);
    
        updateRGB();
    } else {
        playHUD.healthBar.setColors(dad.healthColour, 0xFF0000);
    }

    cosmetic = new FlxSprite(0, 0).loadGraphic(Paths.image('characters/amazon/cosmetics/' + cosmetics[cosmeticnum]));
    cosmeticExtra = new FlxSprite(0, 0);
    switch (cosmetics[cosmeticnum]) {
        case 'dumsticker':
            cosmetic.x += -50;
            cosmetic.y += 60;
        case 'eye':
            cosmetic.x += -100;
            cosmetic.y += 75;
        case 'eyebrows':
            cosmetic.x += -60;
            cosmetic.y += -60;
        case 'eyebrowsmad':
            cosmetic.x += -90;
            cosmetic.y += -50;
        case 'glasses':
            cosmetic.x += -40;
            cosmetic.y += 65;
        case 'reindeernose':
            cosmeticExtra.loadGraphic(Paths.image('characters/amazon/cosmetics/reindeernoseglow'));
            cosmeticExtra.flipY = true;
            cosmeticExtra.origin.set();
            cosmeticExtra.x += -40;
            cosmeticExtra.y += 65;
            cosmeticExtra.blend = BlendMode.ADD;

            doCosmeticExtra = true;

            cosmetic.x += -10;
            cosmetic.y += 35;
        case 'bigasshat':
            cosmetic.x += -250;
            cosmetic.y += 100;
    }
    cosmetic.flipY = true;
    cosmetic.origin.set();

    tooguscosmetic = new animate.internal.elements.FlxSpriteElement(cosmetic);
	tooguscosmetic.active = false;

    if (doCosmeticExtra) {
        tooguscosmeticextra = new animate.internal.elements.FlxSpriteElement(cosmeticExtra);
	    tooguscosmeticextra.active = false;
    }

    var cosmeticsymbol = boyfriend.library.getSymbol('cosmeticpoint');
    cosmeticsymbol.timeline.layers[0].forEachFrame((frame) -> {
		for (i in frame.elements)
			i.visible = false;
		    frame.add(tooguscosmetic);
            if (doCosmeticExtra) frame.add(tooguscosmeticextra);
	});
}

function onUpdate() {
    iconRGB.setFloat('opacity', camHUD.alpha);

    for (ghost in boyfriend.doubleGhosts)
    {
        ghostRGB.setFloat('opacity', boyfriend.doubleGhosts[0].alpha);
        ghost.shader = ghostRGB;
    }
}

function convertColor(col:FlxColor = 0xFFFFFF):Array<Float> {
    var colorArray:Array<Float> = [
        FlxColor.getRed(col) / 255,
        FlxColor.getGreen(col) / 255,
        FlxColor.getBlue(col) / 255
    ];
    return colorArray;
}

function updateRGB() {
    var color:FlxColor = convertColor(colors[crewColor]);
    var visorcolor:FlxColor = convertColor(visorcolors[davisorcolor]);
    bfRGB.setFloatArray('red', color);
    bfRGB.setFloatArray('blue', [color[0]/2, color[1]/2, color[2] / 2 + 0.2]);
    bfRGB.setFloatArray('green', [visorcolor[0], visorcolor[1], visorcolor[2] + 0.2]);

    ghostRGB.setFloatArray('red', color);
    ghostRGB.setFloatArray('blue', [color[0]/2, color[1]/2, color[2] / 2 + 0.2]);
    ghostRGB.setFloatArray('green', [96 / 255, 208 / 255, 1]);
}