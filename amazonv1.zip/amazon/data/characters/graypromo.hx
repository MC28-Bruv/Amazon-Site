function onCreatePost() {
    if (curSong == 'Defeat') rimlightExcludedSkins.push('graypromo');
    else if (curSong == 'Finale') rimlightExcludedSkins.push('graypromo');
}