function onCreatePost() {
    game.songSpeed = 1;
}