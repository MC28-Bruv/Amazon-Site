# AMAZON COSMICUBE
## VERSION 1 - A
- Added the following playable skins:
-- Purple
-- Esculent
-- Esculent (Dead)
-- Promo Gray
-- Loggo
-- Week 2 Walker
-- Impostor Pico
-- Red 70 Years On...

- Added the following speaker skins:
-- Nightmare Black

- Added the following pets:
-- Charles
-- Evil Looksie
-- Hube?!
-- Mother of 40's 40 Crewmates
-- Pink Parasite
-- Tiny Tomongus