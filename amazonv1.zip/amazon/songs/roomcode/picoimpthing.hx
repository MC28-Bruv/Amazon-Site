function onCreatePost() {
	if (ClientPrefs.bfSkin == 'picoimp') {
		addCharacterToList('picoimp', 0);
		triggerEventNote('Change Character', 'boyfriend', 'picoimp');
	}
}