function onCreatePost() {
	if (ClientPrefs.bfSkin == 'toogusCrew') {
		addCharacterToList('toogusCrew', 0);
		triggerEventNote('Change Character', 'boyfriend', 'toogusCrew');

        colors = [0xFFFFFF];
        visorcolors = [0x60D0FF];
	}
}